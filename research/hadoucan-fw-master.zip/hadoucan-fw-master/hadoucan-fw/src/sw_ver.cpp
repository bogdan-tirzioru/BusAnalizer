#include "sw_ver.hpp"

const char GIT_COMMIT[] = GIT_SHA1;
const int SW_VER_MAJOR = 0;
const int SW_VER_MINOR = 1;
const int SW_VER_PATCH = 0;
