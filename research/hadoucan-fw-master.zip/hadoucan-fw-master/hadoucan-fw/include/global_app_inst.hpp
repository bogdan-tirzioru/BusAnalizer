#pragma once

#include "CAN_USB_app.hpp"

//globals
extern CAN_USB_app can_usb_app;
