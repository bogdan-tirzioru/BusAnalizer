#pragma once

extern const char GIT_COMMIT[];
extern const int SW_VER_MAJOR;
extern const int SW_VER_MINOR;
extern const int SW_VER_PATCH;
