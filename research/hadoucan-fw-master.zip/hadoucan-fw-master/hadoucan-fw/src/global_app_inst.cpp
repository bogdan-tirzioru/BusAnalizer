#include "global_app_inst.hpp"

CAN_USB_app can_usb_app __attribute__(( section(".ram_dtcm_noload") ));
